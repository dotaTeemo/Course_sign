import pymysql, datetime

#添加课程
def AddCourseByTeacherID(teacherID, courseName,StudentNumber):
    db_signin = pymysql.connect("192.168.145.121", "root", "dlam1233", "signin")
    cursor = db_signin.cursor()

    id=0
    sql1 = """SELECT count(*) FROM course"""
    try:
        cursor.execute(sql1)
        results = cursor.fetchall()
        for row in results:
            id = row[0]+1

        sql = """INSERT INTO course
             VALUES ('%s','%s', '%s', '%s')""" % (id, courseName, teacherID, StudentNumber)
        cursor.execute(sql)
        db_signin.commit()
        return 'SUCCESS'
    except:
        db_signin.rollback()
        return 'FAIL'
    finally:
        db_signin.close()

#显示老师所教授的课程,应该是在老师最初进入的界面显示
def showCoursesByTeacherID(teacherID):
    db_signin = pymysql.connect("192.168.145.121", "root", "dlam1233", "signin")
    cursor = db_signin.cursor()

    courses=[]
    id=0
    sql = """SELECT * FROM course where teacher_id='%s'""" % (teacherID)
    try:
        cursor.execute(sql)
        results = cursor.fetchall()
        for row in results:
            courses.append({
                'id': row[0],
                'courseName': row[1],
                'teacherid': teacherID,
                'studentNumber': row[3]
            })
        return courses
    except:
        db_signin.rollback()
        return None
    finally:
        db_signin.close()

#开放签到
def addAttend(course_id, sign_number, longitude, latitude, startDate, endDate):
    db_signin = pymysql.connect("192.168.145.121", "root", "dlam1233", "signin")
    cursor = db_signin.cursor()

    # 从前台获取
    studentList=[]

    id=0
    sql1 = """SELECT * FROM student_course where course_id= %s""" % (course_id)
    sql2 = """SELECT count(*) FROM class_sign"""
    try:
        cursor.execute(sql1)
        results = cursor.fetchall()
        for row in results:
            studentList.append(row[2])
        cursor.execute(sql2)
        results = cursor.fetchall()
        for row in results:
            id=row[0]+1
        for stuid in studentList:
            sql = """INSERT INTO class_sign
             VALUES ('%s','%s', '%s', '%s', '%s','%s','%s','%s','%s')""" % (id,stuid,course_id,0,startDate,endDate,sign_number,longitude,latitude)
            cursor.execute(sql)
            db_signin.commit()
            id=id+1
        return str(len(studentList))
    except:
        db_signin.rollback()
        return '0'
    finally:
        db_signin.close()

#查看总签到
def showAttend(course_id):
    db_signin = pymysql.connect("192.168.145.121", "root", "dlam1233", "signin")
    cursor = db_signin.cursor()

    studentList=[]

    id=0
    shouldAttendCount=0
    sql1 = """SELECT * FROM student_course where course_id= %s""" % (course_id)
    attendarr=[]
    try:
        cursor.execute(sql1)
        results = cursor.fetchall()
        for row in results:
            studentList.append(row[2])
        sql = """SELECT count(*) FROM class_sign where course_id= '%s' and student_id='%s'""" % (
        course_id, studentList[0])
        cursor.execute(sql)
        results = cursor.fetchall()
        for row in results:
            shouldAttendCount=row[0]
        for stuid in studentList:
            sql = """SELECT count(*) FROM class_sign where course_id= '%s' and student_id='%s' and issign=1""" % (course_id,stuid)
            cursor.execute(sql)
            results = cursor.fetchall()
            for row in results:
                attendarr.append({
                    'student_id': stuid,
                    'course_id': course_id,
                    'shouldAttend': shouldAttendCount,
                    'actualAttend': row[0]
                })

        return attendarr
    except:
        db_signin.rollback()
        return None
    finally:
        db_signin.close()

#查看实时签到,只能查看缺课学生学号
def showNowAttend(course_id):
    db_signin = pymysql.connect("192.168.145.121", "root", "dlam1233", "signin")
    cursor = db_signin.cursor()

    studentList=[]

    id=0
    shouldAttendCount=0
    attendcount=0
    sql1 = """SELECT * FROM student_course where course_id= %s""" % (course_id)
    attendarr=[]
    try:
        cursor.execute(sql1)
        results = cursor.fetchall()
        for row in results:
            studentList.append(row[2])
        shouldAttendCount=len(studentList)
        now = datetime.datetime.now()
        otherStyleTime = now.strftime("%Y%m%d")
        min = otherStyleTime + '0000'
        max = otherStyleTime + '2400'
        for stuid in studentList:
            sql = """SELECT * FROM class_sign where course_id= '%s' and student_id='%s' and issign=1 and start_date>'%s' and end_date<'%s'""" % (course_id,stuid,max,min)
            cursor.execute(sql)
            results = cursor.fetchall()
            for row in results:
                attendcount+=1
                studentList.remove(stuid)

        return studentList
    except:
        db_signin.rollback()
        return None
    finally:
        db_signin.close()

#显示课程反馈，从前台获取课程id,按日期降序显示
def showComment(course_id):
    db_signin = pymysql.connect("192.168.145.121", "root", "dlam1233", "signin")
    cursor = db_signin.cursor()

    commentarr=[]
    id=0
    sql1 = """SELECT * FROM comment where course_id= %s order by date desc """ % (course_id)
    self=''
    try:
        cursor.execute(sql1)
        results = cursor.fetchall()
        for row in results:
            commentarr.append({
                'studentID': row[1],
                'content': row[2],
                'date': row[3]
            })

        return commentarr

    except:
        db_signin.rollback()
        return None
    finally:
        db_signin.close()

if __name__ == '__main__':
    print(showAttend())